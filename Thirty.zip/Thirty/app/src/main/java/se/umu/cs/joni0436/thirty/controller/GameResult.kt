package se.umu.cs.joni0436.thirty.controller

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class GameResult : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }
}