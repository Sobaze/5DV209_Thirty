package se.umu.cs.joni0436.thirty.controller


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingComponent
import androidx.databinding.Data
import se.umu.cs.joni0436.thirty.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    //private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //binding = ActivityMainBinding.inflate(layoutInflater)
        // val dataBinding =
          //  DatabindingUtil.setContentView<ActivityMainBinding>(this, R.layout.activity_main)
        //setContentView(R.layout.activity_main)
    }
}