package se.umu.cs.joni0436.thirty.model

class Dice {
    // dice has a number from 1-6
    //var diceVal: Int = IntRange(1, 6).random()
    // a dice should be able to be selected
    //var isDiceSelected: Boolean = false;

    fun rollDice() {

    }

    fun selectDice() {

    }


}