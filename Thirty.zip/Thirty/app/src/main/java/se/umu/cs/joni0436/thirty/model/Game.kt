package se.umu.cs.joni0436.thirty.model

class Game {

    // import 6 dices from dice
    var dices: ArrayList<Dice> =
        arrayListOf(Dice(),Dice(),Dice(),Dice(),Dice(),Dice())


    var rounds: Int = 0

    var rolls: Int = 0

    var round: Int = 0

    fun isRoundOver() {

    }

    fun rollDices() {

    }
}